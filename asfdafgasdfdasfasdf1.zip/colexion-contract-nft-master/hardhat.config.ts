import * as dotenv from "dotenv";

import { HardhatUserConfig, task } from "hardhat/config";
import "@nomiclabs/hardhat-etherscan";
import "@nomiclabs/hardhat-waffle";
import "@typechain/hardhat";
import "hardhat-gas-reporter";
import "solidity-coverage";
import "hardhat-contract-sizer";


dotenv.config();

// This is a sample Hardhat task. To learn how to create your own go to
// https://hardhat.org/guides/create-task.html
task("accounts", "Prints the list of accounts", async (taskArgs, hre) => {
  const accounts = await hre.ethers.getSigners();

  for (const account of accounts) {
    console.log(account.address);
  }
});

// You need to export an object to set up your config
// Go to https://hardhat.org/config/ to learn more

const config: HardhatUserConfig & {contractSizer: {
    alphaSort:  boolean,
    disambiguatePaths:  boolean,
    runOnCompile:  boolean,
    strict:  boolean,
    only: string[]
  }} = {
  solidity: "0.8.4",
  contractSizer: {
    alphaSort: true,
    disambiguatePaths: false,
    runOnCompile: true,
    strict: true,
    only: [':ColexionMarketPlace'],
  },
  networks: {
    hardhat: {
      chainId: 1337
    },
    localhost: {
      url: "http://localhost:8545",
      accounts:
          process.env.PRIVATE_KEY !== undefined &&  process.env.PRIVATE_KEY1 !== undefined && process.env.PRIVATE_KEY2 !== undefined && process.env.PRIVATE_KEY3 !== undefined ? [process.env.PRIVATE_KEY, process.env.PRIVATE_KEY1, process.env.PRIVATE_KEY2,  process.env.PRIVATE_KEY3] : [],
    },
    ropsten: {
      url: process.env.ROPSTEN_URL || "",
      accounts:
          process.env.PRIVATE_KEY !== undefined &&  process.env.PRIVATE_KEY1 !== undefined && process.env.PRIVATE_KEY2 !== undefined && process.env.PRIVATE_KEY3 !== undefined ? [process.env.PRIVATE_KEY, process.env.PRIVATE_KEY1, process.env.PRIVATE_KEY2,  process.env.PRIVATE_KEY3] : [],
    },
    mumbai: {
      url: process.env.MUMBAI_TESTNET_URL || "",
      accounts:
          process.env.MUMBAI_PRIVATE_KEY1 !== undefined &&  process.env.MUMBAI_PRIVATE_KEY !== undefined ? [process.env.MUMBAI_PRIVATE_KEY, process.env.MUMBAI_PRIVATE_KEY1] : [],
    },
    polygon: {
      url: process.env.POLYGON_MAINNET_URL || "",
      accounts:
          process.env.POLYGON_KEY1 !== undefined &&  process.env.POLYGON_KEY2 !== undefined && process.env.POLYGON_KEY3 ? [process.env.POLYGON_KEY2, process.env.POLYGON_KEY1, process.env.POLYGON_KEY3] : [],
    }
  },
  gasReporter: {
    enabled: process.env.REPORT_GAS !== undefined,
    currency: "USD",
  },
  etherscan: {
    apiKey: process.env.POLYGONSCAN_API_KEY,
  },
};

export default config;
