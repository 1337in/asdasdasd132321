import { ethers } from "hardhat";
import MarketPlaceUpgradable from "../artifacts/contracts/libraries/proxy/MarketPlaceUpgradeable.sol/MarketPlaceUpgradeableProxy.json"

async function main() {

    const colexionMarketPlace = await ethers.getContractFactory("ColexionMarketPlace");
    const ColexionMarketPlace = await colexionMarketPlace.deploy();
    await ColexionMarketPlace.deployed();

    const [owner, owner1] = await ethers.getSigners();

    console.log("ColexionMarketPlace deployed to:", ColexionMarketPlace.address);

    const upgradableContract = new ethers.Contract("0x706041CDC127CfEbA73c0Bbf46FB64f728F56533", MarketPlaceUpgradable.abi, owner);

    await upgradableContract.connect(owner1).upgradeTo(ColexionMarketPlace.address);

}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});