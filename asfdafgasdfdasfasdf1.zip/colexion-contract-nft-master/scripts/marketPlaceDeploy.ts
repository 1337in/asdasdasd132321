// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `npx hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
import { ethers } from "hardhat";

async function main() {
    // Hardhat always runs the compile task when running scripts with its command
    // line interface.
    //
    // If this script is run directly using `node` you may want to call compile
    // manually to make sure everything is compiled
    // await hre.run('compile');

    // We get the contract to deploy

    const colexionMarketPlace = await ethers.getContractFactory("ColexionMarketPlace");
    const ColexionMarketPlace = await colexionMarketPlace.deploy();
    await ColexionMarketPlace.deployed();

    const colexionMarketProxy = await ethers.getContractFactory("MarketPlaceUpgradeableProxy");
    const [owner, owner1] = await ethers.getSigners();

    console.log("ColexionMarketPlace deployed to:", ColexionMarketPlace.address);


    const vaultInterface = new ethers.utils.Interface([
        "function initialize( uint256 _platformFees, address _admin) external"
    ])

    let data = vaultInterface.encodeFunctionData("initialize", [ 100, owner.address]);
    console.log(ColexionMarketPlace.address, owner1.address, data);
    const clxnProxy = await colexionMarketProxy.deploy(ColexionMarketPlace.address, owner1.address, data);
    await clxnProxy.deployed();



    console.log("Proxy deployed to:", clxnProxy.address);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
