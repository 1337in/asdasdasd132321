import {expect} from "chai";
import {ethers} from "hardhat";
import {Contract} from "@ethersproject/contracts/src.ts/index";

const NativeAddress = "0x0000000000000000000000000000000000000000";

describe("marketPlace", function () {
    let clxnSilver1155: any, colexionMarketPlace: any, erc20TestToken: any, clxnProxy: any, orderId: string;
    it("should deploy ERC20", async function () {
        const TestToken = await ethers.getContractFactory("TestToken");
        erc20TestToken = await TestToken.deploy("Test Token for test", "TTT", 18);
        await erc20TestToken.deployed();
    });
    it("Should deploy nft contract", async function () {
        const CLXNSilver1155 = await ethers.getContractFactory("CLXNSilver1155");
        clxnSilver1155 = await CLXNSilver1155.deploy();
        await clxnSilver1155.deployed();

    });
    it("Should deploy market place contract", async function () {
        const ColexionMarketPlace = await ethers.getContractFactory("ColexionMarketPlace");
        colexionMarketPlace = await ColexionMarketPlace.deploy();
        await colexionMarketPlace.deployed();

        const [owner] = await ethers.getSigners();

        const iniTx = await colexionMarketPlace.initialize(100, owner.address);
        await iniTx.wait();
        expect(await colexionMarketPlace.platformFees()).to.equal(100);

        const setPlatformFees = await colexionMarketPlace.setPlatformFees(200);

        // wait until the transaction is mined
        await setPlatformFees.wait();

        expect(await colexionMarketPlace.platformFees()).to.equal(200);
    });

    it("should mint NFTs", async function () {
        const [owner] = await ethers.getSigners();
        await clxnSilver1155.mintById(owner.address, 5, 5);
        expect(await clxnSilver1155.balanceOf(owner.address, 5)).to.equal(5);
        await clxnSilver1155.setApprovalForAll(colexionMarketPlace.address, 1);
        await colexionMarketPlace.addNftContractSupport(clxnSilver1155.address);
        await colexionMarketPlace.addTokenSupport(erc20TestToken.address);
        expect(await colexionMarketPlace.nftContracts(clxnSilver1155.address)).to.equal(true);
        expect(await colexionMarketPlace.tokensSupport(erc20TestToken.address)).to.equal(true);

    });

    it("should put NFT on sale", async function () {
        const [owner] = await ethers.getSigners();
        await clxnSilver1155.mintById(owner.address, 6, 5);
        const tx = await colexionMarketPlace.placeOrderForSell(6, clxnSilver1155.address, 5, ethers.utils.parseEther("1.0"), NativeAddress, 0, 0);
        const receipt = await tx.wait();
        const interfaceTx = new ethers.utils.Interface(["event OrderCreated(uint256 indexed orderId, uint256 indexed tokenId, uint256 price, address seller, uint16 copies, uint8 salesType, uint256 startTime, uint256 endTime, address paymentToken, address nftContract);"]);
        const data = receipt.logs[1].data;
        const topics = receipt.logs[1].topics;
        const event = interfaceTx.decodeEventLog("OrderCreated", data, topics);
        expect(event.seller).to.equal(owner.address);
        for (const event of receipt.events) {
            // console.log(`Event ${event.event} with args ${event.args}`);
        }

        const OrderId = event.orderId;

        // const holdTx = await colexionMarketPlace.putOrderOnHold(OrderId);
        // await holdTx.wait();
        //
        // console.log(OrderId);

        const orderInfo = await colexionMarketPlace.order(OrderId);

        console.log(orderInfo);

        const balance = await clxnSilver1155.balanceOf(colexionMarketPlace.address, 6);

        console.log(balance);

        await colexionMarketPlace.bulkBuy([OrderId], [5], {
            value: ethers.utils.parseEther("5.0")
        });
    });


    it("should put NFT on sale and cancel Order", async function () {
        const [owner] = await ethers.getSigners();
        await clxnSilver1155.mintById(owner.address, 10, 10);

        await clxnSilver1155.setApprovalForAll(colexionMarketPlace.address, 1);
        const tx = await colexionMarketPlace.placeOrderForSell(10, clxnSilver1155.address, 8, "10000000000000000000", erc20TestToken.address, 0 , 0);
        const receipt = await tx.wait();

        // const txCancel = await colexionMarketPlace.cancelOrder(1);
        // const receiptCancel = await txCancel.wait();

        for (const event of receipt.events) {
            console.log(`Event ${event.event} with args ${event.args}`);
        }
        // expect(await colexionMarketPlace.cancelOrder(2)).to.equal(true);
    });
    it("should be able to buy the NFT", async function () {
        const [, buyer] = await ethers.getSigners();

        await erc20TestToken.connect(buyer).mint("200000000000000000000")
        await erc20TestToken.connect(buyer).approve(colexionMarketPlace.address, "20000000000000000000");
        await colexionMarketPlace.connect(buyer).buyNowWithNative(1, 2, {
            value: ethers.utils.parseEther("0")
        });

    });

    it("Should place Offer sale order", async function () {
        const tokenId = 20, copies = 25;
        const [owner, buyer, bidder1, bidder2] = await ethers.getSigners();
        await clxnSilver1155.mintById(owner.address, tokenId, copies);

        await clxnSilver1155.setApprovalForAll(colexionMarketPlace.address, 1);
        const endTime = parseInt((Date.now() / 1000).toFixed(2)) + 9000;
        const minPrice = ethers.utils.parseEther("0.01");
        const tx = await colexionMarketPlace.placeOrderForSell(tokenId, clxnSilver1155.address, copies, minPrice, erc20TestToken.address, endTime, 0);
        const receipt = await tx.wait();
        const interfaceTx = new ethers.utils.Interface(["event OrderCreated(uint256 indexed orderId, uint256 indexed tokenId, uint256 price, address seller, uint16 copies, uint8 salesType, uint256 startTime, uint256 endTime, address paymentToken, address nftContract);"]);
        const data = receipt.logs[1].data;
        const topics = receipt.logs[1].topics;
        const event = interfaceTx.decodeEventLog("OrderCreated", data, topics);
        expect(event.seller).to.equal(owner.address);
        for (const event of receipt.events) {
            // console.log(`Event ${event.event} with args ${event.args}`);
        }

        orderId = event.orderId;

    });

    it("Place Bid to offer", async function () {
        const [owner, buyer, bidder1, bidder2] = await ethers.getSigners();

        await erc20TestToken.connect(bidder1).mint("200000000000000000000")
        await erc20TestToken.connect(bidder1).approve(colexionMarketPlace.address, "20000000000000000000");

        await erc20TestToken.connect(bidder2).mint("200000000000000000000")
        await erc20TestToken.connect(bidder2).approve(colexionMarketPlace.address, "20000000000000000000");

        await colexionMarketPlace.connect(bidder1).nativePlaceOfferForOrder(orderId, 5, ethers.utils.parseEther("0.5"), {
            value: ethers.utils.parseEther("0")
        });

        const info = await colexionMarketPlace.order(orderId);
        const bids = await colexionMarketPlace.bids(orderId, 0);


        console.log("------------");

        const balanceBefore = await erc20TestToken.balanceOf(owner.address);
        console.log(balanceBefore.toString());
        await colexionMarketPlace.acceptBid(orderId, 0);

        const balanceAfter = await erc20TestToken.balanceOf(owner.address);
        console.log(balanceAfter.toString());
        console.log("------------");

    });

    it("place order and cancel", async function () {
        const [owner, buyer, bidder1, bidder2] = await ethers.getSigners();
        const balanceBefore = await erc20TestToken.connect(bidder2).balanceOf(bidder2.address);
        console.log(balanceBefore.toString());
        await colexionMarketPlace.connect(bidder2).nativePlaceOfferForOrder(orderId, 1, ethers.utils.parseEther("0.6"), {
            value: ethers.utils.parseEther("0")
        });
        const balanceAfter = await erc20TestToken.connect(bidder2).balanceOf(bidder2.address);
        console.log(balanceAfter.toString());
        await colexionMarketPlace.connect(bidder2).withdrawRejectBid(orderId, 1, 0);
        const balanceAfterWithdraw = await erc20TestToken.connect(bidder2).balanceOf(bidder2.address);
        console.log(balanceAfterWithdraw.toString());
    })

      it("Should place Offer sale order native currency", async function() {
          const tokenId = 20, copies = 5;
          const [owner, buyer] = await ethers.getSigners();
          await clxnSilver1155.mintById(owner.address, tokenId, copies);

          await clxnSilver1155.setApprovalForAll(colexionMarketPlace.address, 1);
          const endTime = parseInt((Date.now()/1000).toFixed(2)) + 600;
          const tx = await colexionMarketPlace.placeOrderForSell(tokenId, clxnSilver1155.address,copies, ethers.utils.parseEther("1.0"), NativeAddress, 0 , 0);
          const receipt = await tx.wait();
          console.log("start bought 4 copy")

          const buyTx = await colexionMarketPlace.connect(buyer).buyNowWithNative(3, 4, {
              value: ethers.utils.parseEther("4.0")
          });
          const receiptBuy = await buyTx.wait();
          console.log("bought 4 copy")
          const buyOneTx = await colexionMarketPlace.connect(buyer).buyNowWithNative(3, 1, {
              value: ethers.utils.parseEther("1.0")
          });
          const receiptOneBuy = await buyOneTx.wait();

      });

    it("should place offer ,bid and buy in native", async function() {
         const tokenId = 21, copies = 5;
         const [owner, buyer, seller1, bidder1] = await ethers.getSigners();
         await clxnSilver1155.mintById(seller1.address, tokenId, copies);
         await clxnSilver1155.connect(seller1).setApprovalForAll(colexionMarketPlace.address, 1);
         const endTime = parseInt((Date.now()/1000).toFixed(2)) + 9000;
         const minPrice = ethers.utils.parseEther("0.01")
         const tx = await colexionMarketPlace.connect(seller1).placeOrderForSell(tokenId, clxnSilver1155.address,copies, minPrice, NativeAddress, endTime, 2);
         const receipt = await tx.wait();
         const interfaceTx = new ethers.utils.Interface(["event OrderCreated(uint256 indexed orderId, uint256 indexed tokenId, uint256 price, address seller, uint16 copies, uint8 salesType, uint256 startTime, uint256 endTime, address paymentToken, address nftContract);"]);
         const data = receipt.logs[1].data;
         const topics = receipt.logs[1].topics;
         const event = interfaceTx.decodeEventLog("OrderCreated", data, topics);
         expect(event.seller).to.equal(seller1.address);
         for (const event of receipt.events) {
             // console.log(`Event ${event.event} with args ${event.args}`);
         }

         const orderId = event.orderId;

         const bidTx = await colexionMarketPlace.connect(bidder1).nativePlaceOfferForOrder(orderId, 1, ethers.utils.parseEther("5.0"), {
             value: ethers.utils.parseEther("5.0")
         });

         const bidReceipt = await bidTx.wait();
         const interfaceBidTx = new ethers.utils.Interface(["event BidPlaced(uint256 indexed orderId, uint256 bidIndex, address bidder, uint16 copies, uint256 pricePerNft, uint256 bidTime);"]);
         console.log(bidReceipt.logs);
         const bidData = bidReceipt.logs[0].data;
         const bidTopics = bidReceipt.logs[0].topics;
         const bidEvent = interfaceBidTx.decodeEventLog("BidPlaced", bidData, bidTopics);

         console.log(bidEvent);



         // await colexionMarketPlace.connect(seller1).nativeAcceptBid(orderId, 0);

         // await colexionMarketPlace.connect(bidder1).nativeWithdrawBid(orderId, 0);

         await colexionMarketPlace.connect(seller1).withdrawRejectBid(orderId, 0, 1);

     });

    it("withdraw TOKEN", async function () {
        const provider = ethers.getDefaultProvider();
        const [owner, buyer, seller1, bidder1] = await ethers.getSigners();
        const beforeBalance = await provider.getBalance(colexionMarketPlace.address);
        console.log("Before balance", beforeBalance.toString());
        await colexionMarketPlace.withdrawMoney((ethers.utils.parseEther("5")), NativeAddress);
        const afterBalance = await provider.getBalance(colexionMarketPlace.address);
        console.log("after balance", afterBalance);

        console.log("ERC20 ------------- ERC20");
        const erc20BeforeBalance = await erc20TestToken.balanceOf(colexionMarketPlace.address);
        console.log("Before balance", erc20BeforeBalance.toString());
        await colexionMarketPlace.withdrawMoney(erc20BeforeBalance, erc20TestToken.address);
        const erc20AfterBalance = await erc20TestToken.balanceOf(colexionMarketPlace.address);
        console.log("after balance", erc20AfterBalance);
    });

});
