import { expect } from "chai";
import { ethers } from "hardhat";
import {Contract} from "@ethersproject/contracts/src.ts/index";

describe("silverCard", function () {
    let clxnSilver1155: any;
    it("Should deploy nft contract", async function () {
        const CLXNSilver1155 = await ethers.getContractFactory("CLXNSilver1155");
        clxnSilver1155 = await CLXNSilver1155.deploy();
        await clxnSilver1155.deployed();
    });

    it("should mint NFTs", async function() {
        const [owner] = await ethers.getSigners();
        await clxnSilver1155.mint(owner.address, 5);

        expect(await clxnSilver1155.balanceOf(owner.address, 0)).to.equal(5);
    });

    it("should mint custom NFTs by Id", async function() {
        const [owner] = await ethers.getSigners();
        await clxnSilver1155.mintById(owner.address,15 ,8);

        expect(await clxnSilver1155.balanceOf(owner.address, 15)).to.equal(8);
    });
});